module.exports = {
  "vip_6": {
    "name": "VIP 6 JAM",
    "duration": 6,
    "price": "Rp 8.000",
    "roleId": "1460271659289411698"
  },
  "vip_12": {
    "name": "VIP 12 JAM",
    "duration": 12,
    "price": "Rp 13.000",
    "roleId": "1460271776604098672"
  },
  "vip_24": {
    "name": "VIP 24 JAM",
    "duration": 24,
    "price": "Rp 20.000 (CLOSE)",
    "roleId": "1460271891729223710"
  }
};